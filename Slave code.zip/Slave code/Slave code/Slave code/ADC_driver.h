/*
 * ADC_driver.h
 *
 * Created: 9/27/2021 5:00:21 PM
 *  Author: Mechel Moheb
 */ 


#ifndef ADC_DRIVER_H_
#define ADC_DRIVER_H_
#include "STD_Types.h"
 
void ADC_vinit(void);

 
uint16 ADC_u16Read(void);

#endif  