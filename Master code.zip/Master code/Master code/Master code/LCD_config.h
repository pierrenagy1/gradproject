/*
 * LCD_config.h
 *
 * Created: 9/30/2021 7:55:06 PM
 *  Author: Pierre Nagy
 */ 


#ifndef LCD_CONFIG_H_
#define LCD_CONFIG_H_
#define eight_bits_mode

#endif 